import java.io.* ;
import java.net.* ;
import java.util.* ;


public final class ProcPlus{
	public static Socket clientSocket;
	public static boolean quit = false;	
	public static BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
	
	public static void main(String inputArgs[])throws Exception{
	
		//check the arguments given	
	 		if (inputArgs.length > 0 && inputArgs[0].equals("--help")){
	 			System.out.println("Java client for alk\nSyntax:\njava Proc [address [port]]\n\tif either value is left out, the defaults (localhost and 6791 respectively) are used.\njava Proc --help\n\tShows this help text");
	 			return;
			}

		String address;
		 try {
		 	address = inputArgs[0];
		 } catch (Exception e){
		 	address = "localhost";
		 }
		// Set the port number.
		int port;
		try {
			port = Integer.parseInt(inputArgs[1]);
		} catch (Exception e){
		 	port = 6791;
		}
		// connect to the server
		try {
			clientSocket = new Socket(address, port);
		} catch (Exception e){
			System.out.println("Can't find server - Is it running?  Have you got the port right?");
		}
		
         
		DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
		//sentence = Proc.inFromUser.readLine();
		//String compName=stdout.readLine();
		String compName=command("hostname -i","");
		outToServer.writeBytes("++"+compName + '\n'); //this first message should be the computer's ip address
	String mainOut=command("finger -l","<br>\n");
	outToServer.writeBytes(mainOut);
	System.out.println(mainOut);
	// Close streams and socket.
	outToServer.close();
	clientSocket.close();
	}
	private static String command(String args, String suffix) throws Exception{
		
           Runtime rt = Runtime.getRuntime();
           //System.out.println("About to exec args");
           Process pr = rt.exec(args);
          // System.out.println("did exec, about to read stdout");
           InputStream is = pr.getInputStream();
           BufferedReader stdout = new BufferedReader(new InputStreamReader(is));
           String output="";
           String nextLine=null;
           while ((nextLine=stdout.readLine())!=null){
				output+=nextLine+suffix;
           }
			stdout.close();
			//System.out.println(output);
           return output;
	} 
}
