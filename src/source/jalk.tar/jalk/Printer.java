import java.io.* ;
import java.net.* ;
import java.util.* ;


class Printer extends LabThing{
	
	
private int row;
private int col;
private String name;
private String content="<img src=\"default/loading.gif\" alt=\"Not Processed\" class='loading'>";
private String extra="<img src=\"default/loading.gif\" alt=\"Loading\" class='loading'>";
private Date lastUpdate = new Date(0);
private Process process;
	public Printer(int r, int c){
		this.row=r;
		this.col=c;
	}
	public Printer(int r, int c, String n){
		this.row=r;
		this.col=c;
		this.name=n;
	}
	public String getName(){
		return name;
	}
	
	public String toString(){
		return name;
	}
	
	public int getRow(){
		return row;
	}
	public int getCol(){
		return col;
	}
	
	public String getContent(){
		if (content.indexOf("Not Processed")!=-1) return content;
		return ""+getName()+"";
	}
	public void setContent(String cont){
		if (process!=null)process.destroy();
		content=cont;
		lastUpdate = new Date();
	}
	public String getShort(){
    	String output="";
		try{
           Process pr = Runtime.getRuntime().exec("lpq -sP "+name);
           BufferedReader stdout = new BufferedReader(new InputStreamReader(pr.getInputStream()));
           String nextLine=null;
           while ((nextLine=stdout.readLine())!=null){
				output+=nextLine+"\n";
           }
			stdout.close();
			pr.destroy();
		}
		catch (Exception e){
			System.out.println("Printer (short):"+e);
		}
           return output;
	}
	public String getLong(){
    	String output="";
		try{
           Process pr = Runtime.getRuntime().exec("lpq -P "+name);
           BufferedReader stdout = new BufferedReader(new InputStreamReader(pr.getInputStream()));
           String nextLine=null;
           while ((nextLine=stdout.readLine())!=null){
				output+=nextLine+"<br>\n";
           }
			stdout.close();
			pr.destroy();
		}
		catch (Exception e){
			System.out.println("Printer (long):"+e);
		}
           return output;
	}
	/*public String getExtra() throws Exception{
		Runtime.getRuntime().exec("ssh "+name+" java ProcPlus "+Server.host());
		return "<h3>"+name+"</h3>\n"+extra;
	}
	public void setExtra(String ext){
		extra=ext;
	}
	public void update() throws Exception{
		Date nowDate = new Date();
		long time = nowDate.getTime()-lastUpdate.getTime();
		if (time < (120000)) {
			//less than two mins since last update
			System.out.println("rejected");
			return;
		}
		System.out.println("updated");
		
		process=Runtime.getRuntime().exec("ssh "+name+" java Proc "+Server.host());
	};	*/
	
}
