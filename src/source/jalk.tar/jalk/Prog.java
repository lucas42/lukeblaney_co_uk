import java.io.* ;
import java.net.* ;
import java.util.* ;


class Prog{
	Computer computer;
	int pid;
	String name;
	User user;
	
	public Prog(Computer comp, int id, String procName, User userr){
		computer=comp;
		pid=id;
		name=procName;
		user=userr;
		user.addProc(this);
	}
	public int getPid(){
		return pid;
	}
	
}
