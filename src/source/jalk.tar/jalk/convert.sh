#!/bin/sh
rowpix=100
colpix=100
input=data/labs/
output=data/labs.new/
raw=${outfile}raw/
if [[ `pwd` != *"alk" ]];then
	echo "you are in the wrong directory, exiting"
	exit 1
fi


declare comp
declare -a filelist

		filelist=( `cat "data/maplist"` )
for file in "${filelist[@]}"; do
	if [[ "$file" == "#"* ]]; then
		echo "ignoring ${file}"
	else

			echo  "$output""$file".pic

	

		echo "processing ${file}..."
		exec 4<"${input}${file}".pic

		linenum=0
		unset corrow
		unset corcol

		while read line <&4; do
			
			if [ -n "$line" ]; then
				if [ $corners ]; then
							echo "$line" >> "$output""$file".pic
					if [[ "$line" == "</>"* ]]; then
						unset corners
						linenum=0
					elif [[ "$cornum" = 0 ]]; then
						cornum=1;
						corrow[$corcount]=$line;
					elif [[ "$cornum" = 1 ]]; then
						cornum=0;
						corcol[$corcount]=$line;	
						((corcount++));
						
					fi
				else
					if [ "$linenum" = 0 ]; then
						colmul=1
						rowmul=1
						
						if [[ "$line" == "<>"* ]]; then
							corners=true;
							cornum=0;
							corcount=0;
							echo "$line" >> "$output""$file".pic
						elif [[ "$line" == "++"* ]]; then
							echo "$line" >> "$output""$file".pic
						elif [[ "$line" == "->"* ]]; then
							echo "$line" >> "$output""$file".pic
						elif [[ "$line" == "_-"* ]]; then
							echo "$line" >> "$output""$file".pic
						elif [[ "$line" == "-^"* ]]; then
							echo "$line" >> "$output""$file".pic
						elif [[ "$line" == "=>"* ]]; then
							echo "$line" >> "$output""$file".pic
						elif [[ "$line" == "__"* ]]; then
							echo "$line" >> "$output""$file".pic
						elif [[ "$line" == "--"* ]]; then
							echo "$line" >> "$output""$file".pic
						else
							
							#echo "$line"
						ip=`host -t A "$line" | sed -e 's/^.* \(.*\)/\1/'`
							if [[ "$ip" == "3(NXDOMAIN)" ]]; then
								echo "--used to be $line" >> "$output""$file".pic
							else
								echo "$ip" >> "$output""$file".pic
							fi
							
						fi
							((linenum++));
					elif [ "$linenum" = 1 ]; then
							echo "$line" >> "$output""$file".pic
						row=$(($line * $rowpix))
						((linenum++));
					else
							echo "$line" >> "$output""$file".pic
						col=$(($line * $colpix))
						extracol=$(($col + ($colpix * 2 ) ))
						
						thisrow=$(($rowpix*$rowmul))
						thiscol=$(($colpix*$colmul))
						
						
						linenum=0
					fi
				fi
			fi
		done
		if (( "${#corrow[@]}" <= "${#corcol[@]}" ));then
			cornum=${#corrow[@]}
		else
			cornum=${#corcol[@]}
		fi
		
		echo "done"
	fi
done

