#!/bin/sh
#if [[ ! -n "$1" ]]; then
#	exit 1
#fi
OPTERR=0
#input=jalk/data/maps/
	outfile=~/alk-out/
if ls -l ~/.alk/settings > /dev/null 2>&1; then
	
		exec 6<~/.alk/settings
		while read line <&6; do
			if [[ "$line" == "output="* ]]; then
				outfile=`echo "${line}" | sed s/output=//g `
			fi
		done
fi

rawfile=${outfile}raw/

log=""
hostname=`hostname -s`
procs=`ps -e`

#if  ls -l "${rawfile}${hostname}".tmp > /dev/null 2>&1; then
#	echo "${hostname} file locked"
#	exit
#fi
#echo "" > "${rawfile}${hostname}".tmp
rawdata=`w -hs`
noX="false"
declare -a friends
#exec 5<~/.alk/friendlist
		
#ff=0
#while read friend <&5; do
#	friends[$ff]="${friend}"
#	#echo "$ff${friends[$ff]}"
#	((ff++));
#done

					text=""
					extra=""
							unset users
							declare -a users
							declare -a mainuser
							declare -a xuser
							declare -a xsess
								data=(`echo "${rawdata}" | cut -d' ' -f1 | sort | uniq`)
								users=(`echo "${data[@]}"`) 
								mainuser=(`echo "${rawdata}" | sed s/.*"pts".*//g | sed s/.*"tty".*//g `)
								xuser=(`echo "${mainuser[@]}" | cut -d' ' -f1`)
								xsess=(`echo "${mainuser[@]}" |sed 's/.*[ ]//g' |sed 's/.*\///g'`)
								if [ "${#users[@]}" -gt "0" ]; then
									if [ "${#xuser[@]}" -gt "0" ]; then
										otherusers=($(echo "${users[@]}" | sed s/"${xuser[0]}"//g ))
									else
										text="<span class='noX'>Noone logged into X</span><br>"
										otherusers=("${users[@]}")
										if [[ "${rawdata}" == *"tty"* ]]; then
											noX="true"
										fi
									fi
									extra="<span class='info-title'>${hostname}</span><br>"
									for user in "${xuser[@]}"; do
										fing=`finger -m "${user}"`
										if [ "${fing}" != "" ]; then
											fing=`echo "${fing}" |sed s/" "" "*/" "/g  | sed -e 's/</\&lt;/g'| sed -e 's/>/\&gt;/g' | sed s/$/\<br\>/g`
											#if [[ "${user}" == `whoami` ]]; then
											#	name="Me"
											#else
												name=`echo "${fing}" | grep -i name: | awk -F: '{print $3;}'| sed s/\<br\>//g`; 
											#fi
											face=`echo "${name}" | sed s/" "/"%20"/g `
											facename="<a href='http://www.facebook.com/s.php?q=${face}&n=16777827' target='_blank' onclick=\"return facebook(event,'${face}')\">${name}</a>"
										else
											#text="${text}"
											facename="<!nofinger>${user}</nofinger>"
											fing="<!nofinger>${user}</nofinger>"
											name="<!nofinger>${user}</nofinger>"
										fi
										friendclass=""
										#echo "+++${user}"
										for friend in "${friends[@]}"; do
											#echo "--${friend}"
											if [[ "${user}" == "${friend}" ]]; then
												friendclass=" friend"
												lab=`${1}/c2l -d ${1} ${hostname}`
												if [[ "${user}" == `whoami` ]]; then
													log="${log}<a href='output-${lab}.html#${hostname}'>-me- on ${hostname} in ${lab}</a>"
												else
													log="${log}<a href='output-${lab}.html#${hostname}'>${name} on ${hostname} in ${lab}</a>"
												fi
												#echo "friend: ${user}"
												#if (("${dofriends}")); then
												#	echo "${file}" >> ~/.friendloc.tmp
												#	#echo "output firend"
												#fi
											fi
										done
										text="${text} <span class='name${friendclass}' title='${user}'>${facename}</span><br>"
										extra="${extra}${fing}<br>"
									done
									
									for sess in "${xsess[@]}"; do
										sess=`echo "${sess}" | sed -e 's/</\&lt;/g'| sed -e 's/>/\&gt;/g'`
										if [[ "$sess" == "gnome-session" ]]; then
											#if [[ "$procs" == *"Xsession <defunct>"* ]]; then
											#	text="${text}<span style='color:#090'>gnome (not logged out properly)</span><br>"
											#else
												text="${text}<span class='sess-gnome'>gnome</span><br>"
											#fi
										elif [[ "$sess" == "startkde" ]]; then
											if [[ "$procs" == *"startkde <defunct>"* ]]; then
												text="${text}<span class='sess-kde crashed'>KDE (Crashed)</span><br>"
											else
												text="${text}<span class='sess-kde'>KDE</span><br>"
											fi
										elif [[ "$sess" == "fluxbox" ]]; then
											text="${text}<span class='sess-fluxbox'>fluxbox</span><br>"
										elif [[ "$sess" == "fvwm2" ]]; then
											text="${text}<span class='sess-fvwm'>FVWM</span><br>"
										elif [[ "$sess" == "xinitrc" ]]; then
											text="${text}<span class='sess-xfce'>XFce</span><br>"
										else
											text="${text}<span class='sess-null'>${sess}<br></span>"
										fi
									done
									for user in "${otherusers[@]}"; do
										fing=`finger -m "${user}"`
										if [ "${fing}" != "" ]; then
											fing=`echo "${fing}"  |sed s/" "" "*/" "/g  | sed -e 's/</\&lt;/g'| sed -e 's/>/\&gt;/g' | sed s/$/\<br\>/g`
											name=`echo "${fing}" | grep -i name: | awk -F: '{print $3;}'| sed s/\<br\>//g`; 
											face=`echo "${name}" | sed s/" "/"%20"/g `
											facename="<a href='http://www.facebook.com/s.php?q=${face}&n=16777827' target='_blank' onclick=\"return facebook(event,'${face}')\">(${name})</a>"
										else
											#text="${text}"
											facename="(<!nofinger>${user}</nofinger>)"
											name="${user}"
											fing="<!nofinger>${user}</nofinger>"
										fi
										if [[ "${noX}" == "true" ]]; then
												lab=`${1}/c2l -d ${1} ${hostname}`
											if [[ "${user}" == "s08"* ]]; then
												log="${log}<a href='output-${lab}.html#${hostname}'>Firstie without X Alert: ${name} on ${hostname} in ${lab}</a>"
											else
												log="${log}<a href='output-${lab}.html#${hostname}'>Non X-session:${name} on ${hostname} in ${lab}</a>"
											fi
												#echo "******noX${hostname}*********"
												
										fi
										friendclass=""
										#echo "+++${user}"
										for friend in "${friends[@]}"; do
											#echo "--${friend}"
											if [[ "${user}" == "${friend}" ]]; then
												friendclass=" friend"
												#echo "friend: ${user}"
												#if (("${dofriends}")); then
												#	echo "${file}" >> ~/.friendloc.tmp
												#	#echo "output firend"
												#fi
											fi
										done
										idles=(`echo "${rawdata}" | grep -iP "${user}" |sed s/" "" "*/" "/g| cut -d' ' -f4 | uniq | sed 's/$/,/g' `)
										idle=`echo "${idles[@]}" | sed s/,$/"."/g`
										#for friend in "${friends[@]}"; do
										#	if [[ "${user}" == "${friend}" ]]; then
										#		friendstyle="background:#ff0;"
										#		#echo "nonx friend: ${user}"
										#	fi
										#done
										text="${text} <span class='name${friendclass} noXname' title='${user} idle:${idle}' onclick=\"return facebook(event,'${face}')\">${facename}</span><br>"
										extra="${extra}${fing}<br>"
										#echo "${idles[@]}"
										

									done
									
								else
									text="<span class='free'>FREE</span>"
									extra="<span class='info-title'>${hostname}</span><br>Theres no one currently logged into this computer.<br>"
								fi
					cpu=`cat /proc/cpuinfo | grep "model name" | sed 's/model\ name\t:\ //'`
					ghz=`cat /proc/cpuinfo | grep "model name" |uniq | sed -e 's/.*\ \(.*\)GHz.*/\1/' -e 's/\.//g'`
					ghz=$(($ghz - 150));
					const=12
					colorness=$(($ghz / $const))
					colorness=$((16 - $colorness));
					color=`printf "%x\n" "${colorness}"`
					#echo $colorness
					if [[ "$cpu" == *"Pentium"* ]]; then
						iconclass="pentium"
					elif [[ "$cpu" == *"Core(TM)2 Duo CPU"* ]]; then
						iconclass="duo"
					elif [[ "$cpu" == *"Core(TM)2 CPU"* ]]; then
						iconclass="core2"
					else
						iconclass="otherproc"
					fi
								text="${text}<span class='icon-blank'>.</span><span class='icon-box ' style='background:#ff${color}'>"
									if [[ "$procs" == *"firefox"* ]]; then
										text="${text}<img src='default/firefox.png' class='icons' title='firefox'>"
									fi
									if [[ "$procs" == *"thunderbird"* ]]; then
										text="${text}<img src='default/thunderbird.png' class='icons' title='thunderbird'>"
									fi
									if [[ "$procs" == *"xmms"* ]]; then
										text="${text}<img src='default/xmms.png' class='icons' title='Xmms'>"
									fi
									if [[ "$procs" == *"pidgin"* || "$procs" == *"gaim"* ]]; then
										text="${text}<img src='default/pidgin.png' class='icons' title='pidgin (formerly gaim)'>"
									fi
									if [[ "$procs" == *"skype"* ]]; then
										text="${text}<img src='default/skype.png' class='icons' title='skype'>"
									fi
									if [[ "$procs" == *"gimp"* ]]; then
										text="${text}<img src='default/gimp.png' class='icons' title='the gimp'>"
									fi
									if [[ "$procs" == *"eclipse"* ]]; then
										text="${text}<img src='default/eclipse.png' class='icons' title='eclipse'>"
									fi
									if [[ "$procs" == *"gedit"* ]]; then
										text="${text}<img src='default/gedit.png' class='icons' title='gEdit'>"
									fi
									if [[ "$procs" == *"soffice"* ]]; then
										text="${text}<img src='default/openoffice.png' class='icons' title='OpenOffice.org'>"
									fi
									if [[ "$procs" == *"vim"* ]]; then
										text="${text}<img src='default/vim.png' class='icons' title='vim'>"
									fi
									if [[ "$procs" == *"konqueror"* ]]; then
										text="${text}<img src='default/konqueror.png' class='icons' title='konqueror'>"
									fi
									if [[ "$procs" == *"emacs"* ]]; then
										text="${text}<img src='default/emacs.png' class='icons' title='eMacs'>"
									fi
									if [[ "$procs" == *"seamonkey"* ]]; then
										text="${text}<img src='default/seamonkey.png' class='icons' title='SeaMonkey'>"
									fi
									if [[ "$procs" == *"kate"* ]]; then
										text="${text}<img src='default/kate.png' class='icons' title='kate'>"
									fi
									if [[ "$procs" == *"mplayer"* ]]; then
										text="${text}<img src='default/mplayer.png' class='icons' title='mPlayer'>"
									fi
									if [[ "$procs" == *"kopete"* ]]; then
										text="${text}<img src='default/kopete.png' class='icons' title='kopete(IM)'>"
									fi
									if [[ "$procs" == *"MATLAB"* ]]; then
										text="${text}<img src='default/matlab.png' class='icons' title='MatLab'>"
									fi
									if [[ "$procs" == *"octave"* ]]; then
										text="${text}<img src='default/octave.png' class='icons' title='Octave (GNU alternative to MatLab)	'>"
									fi
									#if [[ "$procs" == *"java"* ]]; then
									#	text="${text}<img src='default/java.png' class='icons' title='Java Process'>"
									#fi
									if [[ "$procs" == *"lukescript"* ]]; then
										text="${text}<img src='default/magnify.jpg' class='icons' title='Nickys script'>"
									elif [[ "$procs" == *"update"* || "$procs" == *"initindexd"* ]]; then
										text="${text}<img src='default/magnify.jpg' class='icons' title='This script'>"
									fi
									text="${text}</span>"
					if [[ "$procs" == *"xlock"* || "$procs" == *"kdesktop_lock"* ]]; then
						text="${text}<span class='lock'>LOCKED</span>"
					fi

					echo "${text}" #> "${rawfile}${hostname}".main
					
					
					#echo "${extra}" #> "${rawfile}${hostname}".extra
					#if [[ "${log}" != "" ]]; then
					#	echo "${log}" > "${rawfile}${hostname}".log
					#fi
					
					
					#${1}/../bin/logintop10 -i /var/log/wtmp -o "${outfile}logs/${hostname}".html -r > /dev/null

					#if ls -l ${outfile}logs/${hostname}.html > /dev/null 2>&1; then
					#	exec 4<"${outfile}logs/${hostname}.html"
					#	read log <&4
					#fi
				#	if [[ -s "${outfile}logs/${hostname}.html" ]]; then
				#		extra="${extra}<form method='post' action='${outfile}logs/${hostname}.html'><input type='submit' value='History'></form>"
					#else
					#	extra="${extra}<form method='post' action='${outfile}logs/${hostname}.html'><input disabled type='submit' value='History not available'></form>"
					#fi
					
					#echo "${extra}" > "${rawfile}${hostname}".extra
