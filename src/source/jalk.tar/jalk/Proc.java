import java.io.* ;
import java.net.* ;
import java.util.* ;


public final class Proc{
	public static Socket clientSocket;
	public static boolean quit = false;	
	public static BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
	
	public static void main(String inputArgs[])throws Exception{
	
		//check the arguments given	
	 		if (inputArgs.length > 0 && inputArgs[0].equals("--help")){
	 			System.out.println("Java client for alk\nSyntax:\njava Proc [address [port]]\n\tif either value is left out, the defaults (localhost and 6791 respectively) are used.\njava Proc --help\n\tShows this help text");
	 			return;
			}

		String address;
		 try {
		 	address = inputArgs[0];
		 } catch (Exception e){
		 	address = "localhost";
		 }
		// Set the port number.
		int port;
		try {
			port = Integer.parseInt(inputArgs[1]);
		} catch (Exception e){
		 	port = 6791;
		}
		// connect to the server
		try {
			clientSocket = new Socket(address, port);
		} catch (Exception e){
			System.out.println("Can't find server - Is it running?  Have you got the port right?");
		}
		
         
       /*    Runtime rt = Runtime.getRuntime();
           //System.out.println("About to exec args");
           Process pr = rt.exec("hostname -s");
          // System.out.println("did exec, about to read stdout");
           InputStream is = pr.getInputStream();
           BufferedReader stdout = new BufferedReader(new InputStreamReader(is));
		*/
		DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
		//sentence = Proc.inFromUser.readLine();
		//String compName=stdout.readLine();
		String compName=command("hostname -i");
		outToServer.writeBytes(compName + '\n'); //this first message should be the computer's ip address
	/*	
		do{ //keep sending messages to server until '\q' is sent
	
		sentence = Proc.inFromUser.readLine();
		
		outToServer.writeBytes(sentence + '\n');
		
		}while (Proc.quit || (sentence.length() < 2 || sentence.charAt(0) != '\\' && sentence.charAt(1) != 'q'));
		Proc.clientSocket.close();
		
	*/
	outToServer.writeBytes(command("jalk/proc.sh")+"\n");
	// Close streams and socket.
	outToServer.close();
	clientSocket.close();
	}
/*	private static String getContent(){
		
	
		String[] finger=comAry("finger");
		String[] xUsers = 
		ArrayList xUsersList = new ArrayList(0);
		if(finger[0].equals("No one logged on.")) return "<span class='free'>FREE</span>";
		
			
		for(i=1;i<finger.length;i++){
			if ((finger[i].indexOf("pts") == -1) && (finger[i].indexOf("tty") == -1)){
				username =
			}
		}		
		userOne=finger[1];
		String[] xUsers = (String[])xUsersList.toArray( new String[ xUsersList.size() ] );
	
	}*/
	private static String command(String args) throws Exception{
		
           Runtime rt = Runtime.getRuntime();
           //System.out.println("About to exec args");
           Process pr = rt.exec(args);
          // System.out.println("did exec, about to read stdout");
           InputStream is = pr.getInputStream();
           BufferedReader stdout = new BufferedReader(new InputStreamReader(is));
           String output="";
           String nextLine=null;
           while ((nextLine=stdout.readLine())!=null){
				output+=nextLine+"\n";
           }
			stdout.close();
			//System.out.println(output);
           return output;
	}
	private static String[] comAry(String args) throws Exception{
		
           Runtime rt = Runtime.getRuntime();
           Process pr = rt.exec(args);
           InputStream is = pr.getInputStream();
           BufferedReader stdout = new BufferedReader(new InputStreamReader(is));
         //  stdout.readLine();//ignore first line
           
           ArrayList output = new ArrayList(0);
           String nextLine=null;
           while ((nextLine=stdout.readLine())!=null){
				output.add(nextLine);
           }
			stdout.close();
			return (String[])output.toArray( new String[ output.size() ] );
	}
}
