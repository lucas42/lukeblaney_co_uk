import java.io.* ;
import java.net.* ;
import java.util.* ;


class LabThing{
	
private int row;
private int col;
private String cssclass;
private String content;
	
	/*public LabThing(int r, int c){
		this.row=r;
		this.col=c;
		this.cssclass="txt";
	}*/
	public LabThing(int r, int c, String css, String con){
		this.row=r;
		this.col=c;
		this.cssclass=css;
		this.content=con;
	}
	public LabThing(){
	
	}
	
	/*public void setRow(int i){
		row = i;
	}
	public void setCol(int i){
		col = i;
	}*/
	
	public int getRow(){
		return row;
	}
	public int getCol(){
		return col;
	}
	public String getCssClass(){
		return cssclass;
	}
	public String getContent(){
		return content;
	}

}
