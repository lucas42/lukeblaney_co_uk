import java.io.* ;
import java.net.* ;
import java.util.* ;


class Computer extends LabThing{
	
	
private int row;
private int col;
private String name;
private String ip;
private String content="<img src=\"default/loading.gif\" alt=\"Not Processed\" class='loading'>";
private String extra="<img src=\"default/loading.gif\" alt=\"Loading\" class='loading'>";
private Date lastUpdate = new Date(0);
private boolean used = false;
private Process process;
private boolean gotName;
private String processor;
private Prog[] processes=new Prog[Server.maxProcs];
	public Computer(int r, int c){
		this.row=r;
		this.col=c;
	}
	public Computer(int r, int c, String ipad){
		this.row=r;
		this.col=c;
		this.ip=ipad;
		String nextLine=null;
		try{
			Process pr = Runtime.getRuntime().exec("host "+ipad);
			BufferedReader stdout = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		   String output="";
			nextLine=stdout.readLine();
			//this.name=nextLine;
			stdout.close();
			pr.destroy();
		}
		catch (Exception e){
			System.out.println("Computer contstructor error (ip address:"+ipad+"): "+e);
		}
		if (nextLine.indexOf("NXDOMAIN")!=-1){
			gotName=false;
			System.out.println("can't find name for "+ipad+" at row "+row+", col "+col);
		}
		else{
			String fullname=nextLine.substring(nextLine.lastIndexOf(" ")+1, nextLine.length());
			//System.out.println(ipad);
			name=fullname.substring(0,fullname.indexOf("."));
			//System.out.println(name);
			gotName=true;
		}
		/*try{
			processor=command("ssh "+ip+" cat /proc/cpuinfo | grep 'model name' | sed 's/model\\ name\\t:\\ //'","");
		}
		catch (Exception e){
			processor="processor not found";
		}*/
	}
	public String getName(){
		if(gotName) return name;
		else //System.out.println("*********************noname");
		 return "noname";
	}
	
	public String toString(){
		return name;
	}
	
	public int getRow(){
		return row;
	}
	public int getCol(){
		return col;
	}
	
	public String getContent(){
		if(gotName){
			if (content.indexOf("Not Processed")!=-1) return content;//+"<span title='"+processor+"'>cpu</span>";
			return "<span class='maincont'><img src=\"default/refresh.png\" class='refresh' onClick=\"forceRefresh('"+getName()+"')\">"+content+"</span>";
		}
		else{
			System.out.println("*********************nonameContent");
			return "<span class='maincont'>No Name</span>";
		}
	}
	public void setContent(String cont){
		if (process!=null)process.destroy();
		content=cont;
		lastUpdate = new Date();
		if ((content.indexOf("FREE") != -1) || (content.indexOf("Not Processed") != -1))used = false;
		else used = true;
		//System.out.println("new content:`"+getContent()+"`");
	}
	public String getExtra() throws Exception{
		if (!gotName)return "not too sure";
		//Runtime.getRuntime().exec("ssh "+ip+" java ProcPlus "+Server.host());
		//return "<h3>"+name+"</h3>\n"+extra;
		   Process pr = Runtime.getRuntime().exec("ssh "+ip+" java ProcPlus "+Server.host());
		   BufferedReader stdout = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		   String output="";
		   String nextLine=null;
		   while ((nextLine=stdout.readLine())!=null){
				output+=nextLine+"\n";
		   }
			stdout.close();
			pr.destroy();
		   return "<h3>"+name+"</h3>\n"+output;
	}
	public void setExtra(String ext){
		extra=ext;
	}
	public void update() throws Exception{
		//if (!gotName)return;
		Date nowDate = new Date();
		long time = nowDate.getTime()-lastUpdate.getTime();
		if ((time < 120000) && used) {
			//less than two mins since last update
			long tleft=120000-(Math.round(time));
			System.out.println("rejected (wait "+tleft+" secs)");
			return;
		}
		System.out.println("updated");
		if (process!=null)process.destroy();
		
		process=Runtime.getRuntime().exec("ssh "+ip+" java Proc "+Server.host());
	}
	public void forceUpdate() throws Exception{
		//if (!gotName)return;
		System.out.println("updated (force)");
		
		Runtime.getRuntime().exec("ssh "+ip+" java Proc "+Server.host());
	}
	public boolean checkPerson(String person){
		//if (!gotName)return false;
		if (content.toLowerCase().indexOf(person.toLowerCase())==-1)return false;
		else return true;
	}
	public String top() throws Exception{
		
		   //return command("ssh "+ip+" ps -eo pid,user,%cpu,args --sort -%cpu","\n");
		   /*BufferedReader stdout = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		   String output="";
		   String nextLine=null;
		   while ((nextLine=stdout.readLine())!=null){
				output+=nextLine+"\n";
		   }
			stdout.close();
			pr.destroy();
		   return output;*/
		   
		   return topSum();
	}
	public String topSum() throws Exception{
			String command="ps -G people -o pid,%cpu,args,user --sort -%cpu";
           Runtime rt = Runtime.getRuntime();
		   Process pr=rt.exec("ssh "+ip+" "+command);
		   BufferedReader stdout = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		   String output="";
		   String nextLine=null;
		   while ((nextLine=stdout.readLine())!=null){
		   		if (nextLine.indexOf(" root")==-1 && nextLine.indexOf("@notty")==-1 && nextLine.indexOf(command.substring(0,20))==-1){
					String user=nextLine.substring(nextLine.lastIndexOf(" "));
					
				   Process pr2=rt.exec("finger "+user);
				   BufferedReader stdout2 = new BufferedReader(new InputStreamReader(pr2.getInputStream()));
				   
				   String oneLine=stdout2.readLine();
				   String name=oneLine.substring(oneLine.indexOf("Name:")+6);
					output+=nextLine.replace(user.trim(),name.trim())+"\n";
				}
		   }
			stdout.close();
			pr.destroy();
		   return output;
	}
	public void updateUsers() throws Exception{
			String command="w -hs | sed 's/\\ \\ */\\ /g'";
           Runtime rt = Runtime.getRuntime();
		   Process pr=rt.exec("ssh "+ip+" "+command);
		   BufferedReader stdout = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		   String output="";
		   String nextLine=null;
		   while ((nextLine=stdout.readLine())!=null){
		   
				int sp1=nextLine.indexOf(" ");
				int sp2=nextLine.indexOf(" ",sp1+1);
				int sp3=nextLine.indexOf(" ",sp2+1);
				int sp4=nextLine.indexOf(" ",sp3+1);
				String username=nextLine.substring(0,sp1);
				//String doing=Integer.parseInt(line.substring(sp4+1));
					String user=nextLine.substring(nextLine.lastIndexOf(" "));
					
				   Process pr2=rt.exec("finger "+user);
				   BufferedReader stdout2 = new BufferedReader(new InputStreamReader(pr2.getInputStream()));
				   
				   String oneLine=stdout2.readLine();
				   String name=oneLine.substring(oneLine.indexOf("Name:")+6);
					output+=nextLine.replace(user.trim(),name.trim())+"\n";
		   }
			stdout.close();
			pr.destroy();
		   //return output;
		
	}
	public void addProc(Prog proc){
		processes[proc.getPid()]=proc;
	}
	private static String command(String args, String suffix) throws Exception{
		
           Runtime rt = Runtime.getRuntime();
           //System.out.println("About to exec args");
           Process pr = rt.exec(args);
          // System.out.println("did exec, about to read stdout");
           InputStream is = pr.getInputStream();
           BufferedReader stdout = new BufferedReader(new InputStreamReader(is));
           String output="";
           String nextLine=null;
           while ((nextLine=stdout.readLine())!=null){
				output+=nextLine+suffix;
           }
			stdout.close();
			//System.out.println(output);
           return output;
	} 
	
}
