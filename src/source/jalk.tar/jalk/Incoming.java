import java.io.* ;
import java.net.* ;
import java.util.* ;
final class Incoming implements Runnable
{
	
	public Incoming() throws Exception
	{
		//System.out.println("incoming server");
	
		}
	// Implement the run() method of the Runnable interface.
	public void run()
	{
		//System.out.println("incoming server-run");
		try {
		processIn();
	} catch (Exception e) {
		System.out.println("Incoming.java Error: "+e);
	}

	}
	private void processIn() throws Exception
	{
			// Set the port number (different from Server.java).
			int port = 6791;
			
			// Establish the listen socket.
			ServerSocket serverSocket = new ServerSocket(port);
    
		System.out.println("Incoming data server ready");
			// Process HTTP service requests in an infinite loop.
			while (true) {
			// Listen for a TCP connection request.
    
				Socket clientSocket = serverSocket.accept();
				//PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
				// Construct an object to process the HTTP request message.
				InRequest request = new InRequest( clientSocket );
				// Create a new thread to process the request.
				Thread thread = new Thread(request);
				// Start the thread.
				thread.start();

			}
	}
}




final class InRequest implements Runnable
{
		final static String CRLF = "\r\n";
	Socket socket;

	// Constructor
	public InRequest(Socket socket) throws Exception
	{
		this.socket = socket;
	}
	// Implement the run() method of the Runnable interface.
	public void run()
	{
		try {
		processRequest();
	} catch (Exception e) {
		System.out.println("Incoming.java (InRequest) Error: "+e);
	}

	}
	private void processRequest() throws Exception
	{
	
	
			// Get a reference to the socket's input and output streams.
			InputStream is = new DataInputStream(socket.getInputStream());
			DataOutputStream os = new DataOutputStream(socket.getOutputStream());
			//
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			
			
		// Get a reference to the socket's input and output streams.

	//System.out.println("in");
	String ip = br.readLine().trim();
		int dot1=ip.indexOf(".");
		int dot2=ip.indexOf(".",dot1+1);
		int dot3=ip.indexOf(".",dot2+1);
		int th=Integer.parseInt(ip.substring(dot2+1,dot3));
		int fr=Integer.parseInt(ip.substring(dot3+1));
		Computer computer = Server.computers[th][fr];
		System.out.println("Data from "+computer.getName());
			
		// Get and display the header lines.
		String content = "";
		String headerLine = null;
		while ((headerLine = br.readLine()) != null) {
			content += headerLine+"\n";
		}
	if (ip.substring(0,2).equals("++")){
		computer.setExtra(content);
	}
	else{
		computer.setContent(content);
	}
		//System.out.println("new content:`"+computer.getContent()+"`from in coming");
	// Close streams and socket.
	os.close();
	br.close();
	socket.close();

	}
}
