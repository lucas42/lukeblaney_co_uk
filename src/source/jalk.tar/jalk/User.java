import java.io.* ;
import java.net.* ;
import java.util.* ;


class User{
private String name;
private String username;
private Prog[] procs=new Prog[Server.maxProcs];
private ArrayList computerList = new ArrayList(0);
	public User(String uun, String na){
		name=na;
		username=uun;
		Server.newUser(this);
	}
	public void addProc(Prog proc){
		procs[proc.getPid()]=proc;
	}
	public void addComp(Computer comp){
		computerList.add(comp);
	}
	public Computer[] getComps(){
		return (Computer[])computerList.toArray( new Computer[ computerList.size() ] );
	}
	public String getUsername(){
		return username;
	}
}
