import java.io.* ;
import java.net.* ;
import java.util.* ;
public final class Server
{
	private static Lab[] labs;
	private static Incoming incoming;
	private static String serverHost;
	private static int boxHeight;
	private static int boxWidth;
	public static Computer[][] computers=new Computer[255][];
	public static int maxProcs;
	private static ArrayList userList=new ArrayList(0);
	public static void main(String argv[]) throws Exception
	{
		Runtime rt=Runtime.getRuntime();
		//get hostname of server
           Process pr = rt.exec("hostname -s");
           InputStream is = pr.getInputStream();
           BufferedReader stdout = new BufferedReader(new InputStreamReader(is));
		serverHost = stdout.readLine();

		stdout.close();
		//
		//get maxProcesses
           Process pr2 = rt.exec("cat /proc/sys/kernel/pid_max");
           InputStream is2 = pr2.getInputStream();
           BufferedReader stdout2 = new BufferedReader(new InputStreamReader(is2));
		maxProcs = Integer.parseInt(stdout2.readLine());

		stdout.close();
		
		//set dimensions of boxes
		boxHeight=100;
		boxWidth=100;
		
		//initiate compArrays
		for (int cc=0; cc<computers.length; cc++){
			computers[cc]=new Computer[255];
		}
		
		//recieve incoming data from proc.class
		incoming = new Incoming();
		Thread inThread = new Thread(incoming);
		inThread.start();
		
		
		
		//read maplist
		BufferedReader brLab = new BufferedReader(new FileReader("data/maplist"));
		String lab;
		ArrayList labsList = new ArrayList(0);
		while((lab=brLab.readLine())!=null){
			if (!lab.equals("")){
				
				Lab newLab = new Lab(lab.trim());	
				labsList.add(newLab);											
			}
		}	
		
		labs = (Lab[])labsList.toArray( new Lab[ labsList.size() ] );
		//System.out.println("=================");
		//5w.printComps();
		
		//Process process = Runtime.getRuntime().exec("ssh fitzroy wall test");
	
			// Set the port number.
			int port = 6789;
			
			// Establish the listen socket.
			ServerSocket serverSocket = new ServerSocket(port);
		System.out.println("outgoing data server ready");
    
			// Process HTTP service requests in an infinite loop.
			while (true) {
				//System.out.println(Server.getLab("test").getContent());
			// Listen for a TCP connection request.
    
				Socket clientSocket = serverSocket.accept();
				//PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
				// Construct an object to process the HTTP request message.
				HttpRequest request = new HttpRequest( clientSocket );
				// Create a new thread to process the request.
				Thread thread = new Thread(request);
				// Start the thread.
				thread.start();

			}
	
		}
	public static Lab getLab(String labName){
		for (int i=0; i<labs.length; i++){
			if(labs[i].getName().trim().equals(labName.trim())) return labs[i];
		}
		//System.out.println("error, lab not found");
		return null;
	}
	public static Printer getPrinter(String printName){
		Printer print;
		for (int i=0; i<labs.length; i++){
			if((print=labs[i].getPrinter(printName))!=null)return print;
			
		}
		return null;
	}
	public static Computer getComputer(String compName){
		Computer comp;
		for (int i=0; i<labs.length; i++){
			if((comp=labs[i].getComputer(compName))!=null)return comp;
			
		}
		return null;
	}
	public static Lab getComputerLab(String compName){
		Computer comp;
		for (int i=0; i<labs.length; i++){
			if((comp=labs[i].getComputer(compName))!=null)return labs[i];
			
		}
		return null;
	}
	public static Computer[] findPerson(String person){
		ArrayList peop=new ArrayList(0);
		for (int i=0; i<labs.length; i++){
			peop.addAll(labs[i].findPerson(person));
		}
		return (Computer[])peop.toArray( new Computer[ peop.size() ] );
	}
	public static void updateAll() throws Exception{
		
		for (int i=0; i<labs.length; i++){
			labs[i].update();
		}
	}
	public static String host(){
		return serverHost;
	}
	public static int height(){
		return boxHeight;
	}
	public static int width(){
		return boxWidth;
	}
	public static String getFrees(){
		String output="<table>\n";
		ArrayList freeLabsList = new ArrayList(0);
		int maxFrees=0;
		for (int i=0; i<labs.length; i++){
			if(labs[i].getFrees()>0){
				freeLabsList.add(labs[i]);
				if (labs[i].getFrees()>maxFrees) maxFrees=labs[i].getFrees();
			}
		}
		
		Lab[] freeLabs = (Lab[])freeLabsList.toArray( new Lab[ freeLabsList.size() ] );
		for (int ll=maxFrees-1; ll>0; ll--){
			
			for (int i=0; i<freeLabs.length; i++){
				if(freeLabs[i].getFrees()==ll){
					output+="<tr><td>"+freeLabs[i].getName()+"</td><td>"+freeLabs[i].getFrees()+"</td></tr>\n";
				}
			}
		}
		output+="</table>";
		return output;
	}
	public static void newUser(User user){
		userList.add(user);
	}
	public static User getUserByUsername(String username){
		
		
		User[] users = (User[])userList.toArray( new User[ userList.size() ] );
		for (int ii=0; ii<users.length; ii++){
			if (users[ii].getUsername().equals(username))return users[ii];
		}
		return null;
	}
	public static User[] getUsersByName(String name){
		
		
		User[] users = (User[])userList.toArray( new User[ userList.size() ] );
		
		ArrayList nameList=new ArrayList(0);
		for (int ii=0; ii<users.length; ii++){
			if (users[ii].getUsername().indexOf(name)!=-1)nameList.add(users[ii]);
		}
		return (User[])nameList.toArray( new User[ nameList.size() ] );
	}
}




final class HttpRequest implements Runnable
{
		final static String CRLF = "\r\n";
	Socket socket;
	String fullHostname;
	String hostname;
	// Constructor
	public HttpRequest(Socket socket) throws Exception
	{
		this.socket = socket;
		fullHostname = socket.getInetAddress().getHostName();
		if (fullHostname.indexOf(".")!=-1)hostname = fullHostname.substring(0,fullHostname.indexOf("."));
		else hostname= socket.getInetAddress().getLocalHost().getHostName().substring(0,socket.getInetAddress().getLocalHost().getHostName().indexOf("."));
	}
	// Implement the run() method of the Runnable interface.
	public void run()
	{
		try {
		processRequest();
	} catch (Exception e) {
		System.out.println("Server Error (HttpRequest, host:"+hostname+"):"+e);
	}

	}
	private void processRequest() throws Exception
	{
	
	
			// Get a reference to the socket's input and output streams.
			InputStream is = new DataInputStream(socket.getInputStream());
			DataOutputStream os = new DataOutputStream(socket.getOutputStream());
			//
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			
			
		// Get a reference to the socket's input and output streams.

	String requestLine = br.readLine();
	// Display the request line.
	//System.out.println("Request from: "+hostname);
	//System.out.println(requestLine);


	// Get and display the header lines.
	String headerLine = null;
	while ((headerLine = br.readLine()).length() != 0) {
		//if (headerLine.indexOf("Referer:")!=-1)System.out.println(headerLine);
	}
	// Extract the filename from the request line.
	StringTokenizer tokens = new StringTokenizer(requestLine);

	tokens.nextToken(); // skip over the method, which should be "GET"
	String fileName = tokens.nextToken();
	// Prepend a "." so that file request is within the current directory.
	fileName = "." + fileName;
	if (fileName.indexOf("map-")==-1){
		//not a map
		if (fileName.indexOf("computer-")==-1){
			//not *computer-
			if (fileName.indexOf("printer-")==-1){
				if (fileName.indexOf("updateAll")!=-1){
					Server.updateAll();
					System.out.println("***Updating All***");
					os.writeBytes("http/1.1 200 Computer Found\n");
					// Send the Server line.
					os.writeBytes("Server: jalk by L. Blaney\n");
					// Send the content type line.
					os.writeBytes("Content-type: text/plain\n");
					os.writeBytes(CRLF);
				}
				else{
					if (fileName.indexOf("frees")!=-1){
						
						System.out.println("#Frees");
						os.writeBytes("http/1.1 200 Found\n");
						// Send the Server line.
						os.writeBytes("Server: jalk by L. Blaney\n");
						// Send the content type line.
						os.writeBytes("Content-type: text/html\n");
						os.writeBytes(CRLF);
						os.writeBytes("<html><head><title>Free Computers</title></head>\n<body>");
						os.writeBytes(Server.getFrees());
						os.writeBytes("</body></html>");
					}
					else if (fileName.equals("./")){
					
					Lab lab; 
						if((lab = Server.getComputerLab(hostname))!=null){
							os.writeBytes("http/1.1 301 Computer Found\n");
							os.writeBytes("Location: map-"+lab+"#"+hostname+"\n");
						}
						else{
							
							os.writeBytes("http/1.1 301 Computer Not Found\n");
							os.writeBytes("Location: map-5w\n");
						}
						// Send the Server line
						os.writeBytes("Server: jalk by L. Blaney\n");
						// Send the content type line.
						os.writeBytes("Content-type: text/plain\n");
						os.writeBytes(CRLF);
						
					}
					else{
					// Open the requested file.
					FileInputStream fis = null;
					boolean fileExists = true;
					try {
						fis = new FileInputStream(fileName);
					} catch (FileNotFoundException e) {
						fileExists = false;
					}



					// Construct the response message.
					String statusLine = null;
					String contentTypeLine = null;
					String entityBody = null;
					if (fileExists) {
						 statusLine = "http/1.1 200 File Found\n";
						 contentTypeLine = "Content-type: " +
							 contentType( fileName ) + CRLF;
					} else {
						 statusLine = "http/1.1 404 File Not Found\n";
						 contentTypeLine = "Content-type:text/xhtml\n";
						 entityBody = "<HTML>" +
							 "<HEAD><TITLE>Not Found</TITLE></HEAD>" +
							 "<BODY>Not Found</BODY></HTML>";
					}
					// Send the status line.
					os.writeBytes(statusLine);
					// Send the Server line.
					os.writeBytes("Server: jalk by L. Blaney\n");
					// Send the content type line.
					os.writeBytes(contentTypeLine);
					// Send a blank line to indicate the end of the header lines.
					os.writeBytes(CRLF);

					// Send the entity body.
					if (fileExists) {
						 sendBytes(fis, os);
						 fis.close();
					} else {
						 os.writeBytes("error");
					}
					}
				}
			}
			else{
				//printer
				String printName;
				if (fileName.indexOf("longprinter-")!=-1){
					printName=fileName.substring(14);
				}
				else{
					printName=fileName.substring(10);
				}
				Printer print=Server.getPrinter(printName);
				if (print==null){
				
						System.out.println("P"+printName+"(long");
						//Computer computer = Server.getComputer(compName);
						os.writeBytes("http/1.1 404 Printer Not Found\n");
						// Send the Server line.
						os.writeBytes("Server: jalk by L. Blaney\n");
						// Send the content type line.
						os.writeBytes("Content-type: text/html\n");
						os.writeBytes(CRLF);
						//computer.update();
						os.writeBytes("printer not found:"+printName);
				}
				else{
					if (fileName.indexOf("longprinter-")!=-1){
						System.out.println("P"+printName+"(long");
						//Computer computer = Server.getComputer(compName);
						os.writeBytes("http/1.1 200 Printer Found\n");
						// Send the Server line.
						os.writeBytes("Server: jalk by L. Blaney\n");
						// Send the content type line.
						os.writeBytes("Content-type: text/plain\n");
						os.writeBytes(CRLF);
						//computer.update();
						os.writeBytes(print.getLong());
						
					}
					else{
						System.out.println("P"+printName);
						//Computer computer = Server.getComputer(compName);
						os.writeBytes("http/1.1 200 Printer Found\n");
						// Send the Server line.
						os.writeBytes("Server: jalk by L. Blaney\n");
						// Send the content type line.
						os.writeBytes("Content-type: text/plain\n");
						os.writeBytes(CRLF);
						//computer.update();
						os.writeBytes(print.getShort());
					}
				}
			}
		}
		else{
			if (fileName.indexOf("findcomputer-")!=-1){
				String compName=fileName.substring(15);
				System.out.println("Find "+compName);
				Lab lab;
				if ((lab = Server.getComputerLab(compName))!=null){
					os.writeBytes("http/1.1 301 Computer Found\n");
					os.writeBytes("Location: map-"+lab+"#"+compName+"\n");
					// Send the Server line
					os.writeBytes("Server: jalk by L. Blaney\n");
					// Send the content type line.
					os.writeBytes("Content-type: text/plain\n");
					os.writeBytes(CRLF);
				}
				else{
					//not a computer, check people
					String person=compName;
					Computer[] comprs=Server.findPerson(person);
					//System.out.println("list");
					if (comprs.length==0){
						os.writeBytes("http/1.1 404 Computer Not Found\n");
						os.writeBytes("Server: jalk by L. Blaney\n");
						os.writeBytes("Content-type: text/html\n");
						os.writeBytes(CRLF);
						os.writeBytes("<html><head><title>Search Results</title></head>\n<body>");
						os.writeBytes("Can't find \""+person+"\"");
						os.writeBytes("<br><form onSubmit='return false'><input type='text' id='searchname' value='"+person+"'><input type='submit' value='Search' onClick=\"window.location='findcomputer-'+document.getElementById('searchname').value\"></form>");	
						os.writeBytes(command("finger "+person));
						os.writeBytes("</body></html>");
					}
					else if (comprs.length==1){
						os.writeBytes("http/1.1 301 Person Found\n");
						os.writeBytes("Location: map-"+Server.getComputerLab(comprs[0].getName())+"#"+comprs[0]+"\n");
						os.writeBytes("Server: jalk by L. Blaney\n");
						os.writeBytes("Content-type: text/plain\n");
						os.writeBytes(CRLF);
							String compuName=comprs[0].getName();
						os.writeBytes("found \""+person+"\" in <a href='map-"+Server.getComputerLab(compuName)+"#"+compuName+"'>");
							os.writeBytes(comprs[0]+", "+Server.getComputerLab(compuName)+"</a>");
					}
					else{
						os.writeBytes("http/1.1 200 Person Found\n");
						os.writeBytes("Server: jalk by L. Blaney\n");
						os.writeBytes("Content-type: text/html\n");
						os.writeBytes(CRLF);
						os.writeBytes("<html><head><title>Search Results</title></head>\n<body>");
						os.writeBytes("Multiple Results were found:\n<ul>\n");
						for (int i=0;i<comprs.length;i++){
							String compuName=comprs[i].getName();
							os.writeBytes("<li><a href='map-"+Server.getComputerLab(compuName)+"#"+compuName+"'>");
							os.writeBytes(comprs[i]+", "+Server.getComputerLab(compuName)+"</a></li>\n");
						}
						os.writeBytes("</ul>\n");
						os.writeBytes("<br><form onSubmit='return false'><input type='text' id='searchname' value='"+person+"'><input type='submit' value='Search' onClick=\"window.location='findcomputer-'+document.getElementById('searchname').value\"></form>");
						os.writeBytes("</body></html>");
					}
				}
			}
			else if (fileName.indexOf("forcecomputer-")!=-1){
				
				
				String compName=fileName.substring(16);
				System.out.println("FORCE: " + compName);
				Computer computer = Server.getComputer(compName);
				os.writeBytes("http/1.1 200 Computer Found\n");
				// Send the Server line.
				os.writeBytes("Server: jalk by L. Blaney\n");
				// Send the content type line.
				os.writeBytes("Content-type: text/plain\n");
				os.writeBytes(CRLF);
				computer.forceUpdate();
				//os.writeBytes(computer.getContent());
				
				
				
			}
			else if (fileName.indexOf("extracomputer-")!=-1){
				String compName=fileName.substring(16);
				System.out.println("`ssh " + compName + " finger -l`");
				Computer computer = Server.getComputer(compName);
				os.writeBytes("http/1.1 200 Computer Found\n");
				// Send the Server line.
				os.writeBytes("Server: jalk by L. Blaney\n");
				// Send the content type line.
				os.writeBytes("Content-type: text/html\n");
				os.writeBytes(CRLF);
				//computer.update();
				os.writeBytes(computer.getExtra());
			}
			else if (fileName.indexOf("topcomputer-")!=-1){
				String compName=fileName.substring(14);
				System.out.println("`ssh " + compName + " top`");
				Computer computer = Server.getComputer(compName);
				os.writeBytes("http/1.1 200 Computer Found\n");
				// Send the Server line.
				os.writeBytes("Server: jalk by L. Blaney\n");
				// Send the content type line.
				os.writeBytes("Content-type: text/html\n");
				os.writeBytes(CRLF);
				os.writeBytes(computer.top());
			}
			else{
				String compName=fileName.substring(11);
				System.out.print("-"+compName+"…");
				Computer computer = Server.getComputer(compName);
				os.writeBytes("http/1.1 200 Computer Found\n");
				// Send the Server line.
				os.writeBytes("Server: jalk by L. Blaney\n");
				// Send the content type line.
				os.writeBytes("Content-type: text/plain\n");
				os.writeBytes(CRLF);
				computer.update();
				os.writeBytes(computer.getContent());
			}
			
		}
	}
	else{
	//map
		String mapName=fileName.substring(6);	
		// Send the status line.
		Lab lab;
		if((lab=Server.getLab(mapName))==null){
			os.writeBytes("http/1.1 404 Lab Not Found\n");
			// Send the Server line.
			os.writeBytes("Server: jalk by L. Blaney\n");
			// Send the content type line.
			os.writeBytes("Content-type: text/plain\n");
			os.writeBytes(CRLF);
			os.writeBytes("Error 404: Lab not Found\n");
			
		}
		else{
			System.out.println("Request from: "+hostname);
			System.out.println("mapping "+mapName);
			os.writeBytes("http/1.1 200 File Found\n");
			// Send the Server line.
			os.writeBytes("Server: jalk by L. Blaney\n");
			// Send the content type line.
			os.writeBytes("Content-type: text/html\n");
			// Send a blank line to indicate the end of the header lines.
			os.writeBytes(CRLF);
			BufferedReader headbr = new BufferedReader(new FileReader("header"));
			String line=null;
			while((line=headbr.readLine())!=null){
				os.writeBytes(line+"\n");
			}
			
			os.writeBytes(lab.getContent(hostname));
			lab.update();
			os.writeBytes("<span id='stats' style='display:none;'><form onSubmit='return false'><input type='text' id='searchname'><input type='submit' value='Search' onClick=\"window.location='findcomputer-'+document.getElementById('searchname').value\"></form></span><input type='button' value='&gt' onClick=\"getElementById('stats').style.display='none'; getElementById('shower').style.display=''\" id='hider'><input type='button' value='&lt' onClick=\"getElementById('stats').style.display='';this.style.display='none';updateAll()\" id='shower' style=''>\n");
			os.writeBytes("<span id='cover' onClick='stoptop()'></span><span id='extra'></span>");
			os.writeBytes("</body></html>");
		}
		
	}	
	// Close streams and socket.
	os.close();
	br.close();
	socket.close();

	}



	private static void sendBytes(FileInputStream fis, OutputStream os)
throws Exception
{
   // Construct a 1K buffer to hold bytes on their way to the socket.
   byte[] buffer = new byte[1024];
   int bytes = 0;
   // Copy requested file into the socket's output stream.
   while((bytes = fis.read(buffer)) != -1 ) {
      os.write(buffer, 0, bytes);
   }
}

	private static String contentType(String fileName)
{
	if(fileName.endsWith(".htm") || fileName.endsWith(".html")) {
		return "text/html";
	}
	if(fileName.endsWith(".png")) {
		return "image/png";
	}
	if(fileName.endsWith(".gif")) {
		return "image/gif";
	}
	if(fileName.endsWith(".jpg")) {
		return "image/jpeg";
	}
	if(fileName.endsWith(".css")) {
		return "text/css";
	}
	return "application/octet-stream";
}
	private static String command(String args) throws Exception{
		
           Runtime rt = Runtime.getRuntime();
           //System.out.println("About to exec args");
           Process pr = rt.exec(args);
          // System.out.println("did exec, about to read stdout");
           InputStream is = pr.getInputStream();
           BufferedReader stdout = new BufferedReader(new InputStreamReader(is));
           String output="";
           String nextLine=null;
           while ((nextLine=stdout.readLine())!=null){
				output+=nextLine+"<br>\n";
           }
			stdout.close();
			//System.out.println(output);
           return output;
	}

}
