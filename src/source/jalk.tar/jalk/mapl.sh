#!/bin/sh
rowpix=100
colpix=100
input=data/
	outfile=~/alk-out/
if ls -l ~/.alk/settings > /dev/null 2>&1; then
	
		exec 6<~/.alk/settings
		while read line <&6; do
			if [[ "$line" == "output="* ]]; then
				outfile=`echo "${line}" | sed s/output=//g `
			fi
		done
fi


raw=${outfile}raw/
if [[ `pwd` != *"alk" ]];then
	echo "you are in the wrong directory, exiting"
	exit 1
fi

echo `date` > "${outfile}"log.temp
#cp ${input}*.css ${outfile}
echo "Drawing Maps ***************************************"


declare comp
declare -a filelist

if [ "$1" = "comp" ]; then
	comp="comp-"
	shift
fi
if [ ! -n "$1" ]; then
	echo "choose lab"
	read lab
	filelist[0]="$lab"

else
	if [ $1 = "all" ]; then
		filelist=( `cat "${input}maplist"` )
	else
		filelist=( `echo "$*"` )
	fi
fi

for file in "${filelist[@]}"; do
	if [[ "$file" == "#"* ]]; then
		echo "ignoring ${file}"
	elif  ls -l "${outfile}"output-"${comp}$file".html.tmp > /dev/null 2>&1; then
		echo "${file} being processed elsewhere"
	else


		echo "<html><head><title>Output from Lab ${file} at " > "${outfile}"output-"${comp}$file".html.tmp
		echo `date` >> "${outfile}"output-"${comp}$file".html.tmp
		echo "</title><LINK href='style.css' rel='stylesheet' type='text/css'><script type='text/javascript'>" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "<!--" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "function toggle(titl){" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "var elem = document.getElementById(titl);" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "if(elem.style.display == 'none')	elem.style.display= 'block';" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "else elem.style.display= 'none';" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "}" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "function hidestat(){" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "var elem = document.getElementById(stats);" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "if(elem.style.display == 'none')	{elem.style.display= 'fixed';" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "elem.style.display= 'fixed';" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "}" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "else elem.style.display= 'none';" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "}" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "url=\"file://${outfile}log\"" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "//-->" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "</script>" >> "${outfile}"output-"${comp}$file".html.tmp
		cat  "${input}header">> "${outfile}"output-"${comp}$file".html.tmp
		#echo "</head><body>" >> "${outfile}"output-"${comp}$file".html.tmp

		echo "processing ${file}..."
		exec 4<"${input}${file}".pic
		#Convert really slows down the script
		#convert -size 800x85 xc:transparent -font Bookman-DemiItalic -pointsize 72 -draw "text 25,60 'processing ${file}...'" -channel RGBA -gaussian 0x6 -fill darkred -stroke red -draw "text 20,55 'processing ${file}...'" "${outfile}"processing.png

		linenum=0
							unset corrow
							unset corcol

		while read line <&4; do
			
			
			if [ -n "$line" ]; then
				if [ $corners ]; then
					if [[ "$line" == "</>"* ]]; then
						unset corners
						linenum=0
					elif [[ "$cornum" = 0 ]]; then
						cornum=1;
						corrow[$corcount]=$line;
					elif [[ "$cornum" = 1 ]]; then
						cornum=0;
						corcol[$corcount]=$line;	
						((corcount++));
						
					fi
				else
					if [ "$linenum" = 0 ]; then
						colmul=1
						rowmul=1
						text=""
						extra=""
						extraclick=""
						
						class="box"
						classinfo="info"
						if [[ "$line" == "<>"* ]]; then
							corners=true;
							cornum=0;
							corcount=0;
						elif [[ "$line" == "++"* ]]; then
							line=`echo "${line}" | sed s/"++"//g`
							text="$line"
							if [ -n "$comp" ]; then
								title="$line"
							else
								data=`lpq -P${line} -s`
								title=`echo "${data}" |sed s/"@linotype"// | sed s/.*"message: "//g`				#message onwards
								others=`echo "${data}" | cut -d' ' -f2,3 ` #words 2 & 3
							fi
							class="${class} printer"
							classinfo="${classinfo} printer-info"
							
							extra="<span class='info-title'>${title}</span><br>"`lpq -P${line} -l`"<br>"
							
							extraclick=" onClick=\"toggle('hidden${title}')\""
						elif [[ "$line" == "->"* ]]; then
							door=`echo "${line}" | sed s/"->"//g`
							others=""
							pic="door.png"
							text="<a href='output-${comp}${door}.html#${file}'><img src='${pic}' alt='${door}' style='height:${rowpix}px;width:${colpix}px;border:none;'></a>"
							
							title="$door"
							class="${class} door"
						elif [[ "$line" == "_-"* ]]; then
							if [[ `echo "${line}" | sed 's/_-\(.\).*/\1/g'` == "u" ]]; then
								stairDir="up"
							elif [[ `echo "${line}" | sed 's/_-\(.\).*/\1/g'` == "d" ]]; then
								stairDir="down"
							fi
							if [[ `echo "${line}" | sed 's/_-.\(.\).*/\1/g'` == "l" ]]; then
								stairSide="left"
							elif [[ `echo "${line}" | sed 's/_-.\(.\).*/\1/g'` == "r" ]]; then
								stairSide="right"
							fi
							stair=`echo "${line}" | sed s/"_-"..//g`
							others=""
							pic="stairs_${stairDir}_${stairSide}.png"
							rowmul=1
							colmul=2
							thisrow=$(($rowpix*$rowmul))
							thiscol=$(($colpix*$colmul))
							text="<a href='output-${comp}${stair}.html#${file}'><img src='${pic}' alt='${stair}' style='height:${thisrow}px;width:${thiscol}px;border:none;'></a>"
							
							title="$stair"
							class="${class} stair"
						elif [[ "$line" == "-^"* ]]; then
							lift=`echo "${line}" | sed s/"-^"//g`
							others=""
							pic="lift.png"
							text="<a href='output-${comp}${lift}.html#${file}'><img src='${pic}' alt='${lift}' style='height:${rowpix}px;width:${colpix}px;border:none;'></a>"
							
							title="$lift"
							class="${class} lift"
						elif [[ "$line" == "=>"* ]]; then
							level=`echo "${line}" | sed s/"=>"//g`
							#title=`echo "Level $level"`  N.B. id and title should differ
							title=`echo "${level}l"`
							others=""
							text="<form method='post' action='output-${comp}${level}l.html#${file}'><input type='submit' value='${level}' style='height:100px;width:100%;'></form>"
							
							class="${class} button"
						elif [[ "$line" == "__"* ]]; then
							text=`echo "${line}" | sed s/"__"//g`
							others=""
							title="$text"
							
							class="${class} txt"
						elif [[ "$line" == "--"* ]]; then
							text=`echo "${line}" | sed s/"--"//g`
							others=""
							title="$text"
							
							class="${class} txt-bordered"
						else
							host=$line
							class="${class} computer"
							classinfo="${classinfo} computer-info"
							if [ -n "$comp" ]; then
								text="$host"
							else
								extraclick=" onClick=\"toggle('hidden${host}')\""
								if ls -l "${raw}${host}.main" > /dev/null 2>&1; then
									text=`cat "${raw}${host}.main"`
									extra=`cat "${raw}${host}.extra"`
									if [[ "${text}" == *"<!nofinger>"* ]]; then
									
										user=`echo "${text}"  | sed 's/.*<!nofinger>\(.*\)<\/nofinger>.*/\1/g' `
										fing=`finger -m "${user}"   | sed 's/Last login.*/No finger./;s/Never logged in.*/No finger./'|sed s/" "" "*/" "/g  | sed -e 's/</\&lt;/g;s/>/\&gt;/g' | sed s/$/\<br\>/g`
										
										
										if [[ "${user}" == `whoami` ]]; then
											name="Me"
										else
											name=`echo "${fing}" | grep -i name: | awk -F: '{print $3;}'| sed s/\<br\>//g`; 
										fi
										
										face=`echo "${name}" | sed s/" "/"%20"/g ` 
										facename="\<a href='http:\/\/www.facebook.com\/s.php\?q\=${face}' target='_blank'\>${name}\<\/a\>"
										#echo "$fing" 
										nofingopen='<!nofinger>'
										nofingclose='<\/nofinger>'
										text=`echo "${text}" | sed s/"$nofingopen".*"$nofingclose"/"$facename"/g `
										extra=`echo "${extra}" | sed s/"$nofingopen".*"$nofingclose"/\<br\>/g `
										extra="${extra}${fing}"
										#extra=`echo "${extra}" | sed s/"$nofingopen".*"$nofingclose"/"$fing"/g ` # | sed s/$/\<br\>/g |sed s/" "" "*/" "/g
										#extra=`echo "${extra}" | sed s/"${nofingopen}"/"$fing"/g `
										
										if ls -l "${raw}${host}".log > /dev/null 2>&1; then
											cat "${raw}${host}".log | sed s/"$nofingopen".*"$nofingclose"/"$name"/g > "${raw}${host}".log 
										fi

										
									fi
									
									
									
									
								else
							class="${class} computer-broken"
							classinfo="${classinfo} computer-broken-info"
									text="<span>BROKEN</span>"
									extra="<span class='info-title'>${host}</span><br>There is a response from ping, so I'm not quite sure whats wrong with this computer"
								fi
										
							fi
							title="$host"
							
							if ls -l "${raw}${host}".log > /dev/null 2>&1; then
								#echo "found log for ${host}"
								echo "<br>" >> "${outfile}"log.temp
								cat "${raw}${host}.log" >> "${outfile}"log.temp
							fi
							
						fi
							((linenum++));
					elif [ "$linenum" = 1 ]; then
						row=$(($line * $rowpix))
						((linenum++));
					else
						col=$(($line * $colpix))
						extracol=$(($col + ($colpix * 2 ) ))
						
						thisrow=$(($rowpix*$rowmul))
						thiscol=$(($colpix*$colmul))
						
						echo "<span class='${class}' style='top:${row}px;left:${col}px;min-height:${thisrow}px;width:${thiscol}px;' title='${title}' id='${title}'${extraclick}>${text}</span><span class='${classinfo}' style='display:none;top:${row}px;left:${extracol}px;' id='hidden${title}' onClick=\"this.style.display='none'\">${extra}</span><br>" >> "${outfile}"output-"${comp}$file".html.tmp
						

						
						
						
						
						linenum=0
					fi
				fi
			fi
		done
		if (( "${#corrow[@]}" <= "${#corcol[@]}" ));then
			cornum=${#corrow[@]}
		else
			cornum=${#corcol[@]}
		fi
		#echo $cornum
		for (( i=1; i<$cornum; i+=1 )); do
			#echo "i=$i"
			#echo ${corcol[@]}
			if (( ${corrow[$i]} < ${corrow[${i}-1]} )); then
				cortop=$((${corrow[$i]} * $rowpix))
				corbot=$((${corrow[${i}-1]} * $rowpix))
			else
				corbot=$((${corrow[$i]} * $rowpix))
				cortop=$((${corrow[${i}-1]} * $rowpix))
			fi
			#echo "cortop=${cortop}"
			if (( ${corcol[$i]} > ${corcol[${i}-1]} )); then
				#echo "right"
				corrgt=$((${corcol[$i]} * $rowpix))
				corlft=$((${corcol[${i}-1]} * $rowpix))
			else
				#echo "left=${corcol[${i}]}, right=${corcol[${i}-1]}"
				test=$((3 * $rowpix))
				#echo $test
				corlft=$((${corcol[${i}]} * $rowpix))
				corrgt=$((${corcol[${i}-1]} * $rowpix))
				#echo "corlft=${corlft}"
			fi
			#echo "corrgt=${corrgt}"
			top=$cortop
			height=$(($corbot - $cortop ))
			left=$corlft
			width=$(($corrgt - $corlft ))
			#echo "top=${top}, bottom=${corbot}"
			echo "<div class='wall row' style='border:solid;top:${top}px;height:${height}px;left:${left}px;width:${width}px;margin:0;position:absolute;color:green'></div>">> "${outfile}"output-"${comp}$file".html.tmp 
			#if [[ ${corr
			#	echo "by row"
				
			#	row=$((${corrow[$i]} * $rowpix))
			#	echo "<div class='wall row' style='border-top:solid;top:${row}px;width:${rowpix}px'>wall</div>">> "${outfile}"output-"${comp}$file".html.tmp                
			#elif [[ ${corcol[$i]} == ${corcol[${i}-1]} ]]; then
			#	echo "by col"
			
			#else
			#	echo "error: - points are not in line"
			#fi
			
		done
		echo "<div id='stats' style='display:none;'></div><input type='button' value='&gt' onClick=\"getElementById('stats').style.display='none'; getElementById('shower').style.display=''\" id='hider'><input type='button' value='&lt' onClick=\"getElementById('stats').style.display='';this.style.display='none';makeRequest()\" id='shower' style=''>" >> "${outfile}"output-"${comp}$file".html.tmp
		echo "</body></html>" >> "${outfile}"output-"${comp}$file".html.tmp
		cp "${outfile}"output-"${comp}$file".html.tmp "${outfile}"output-"${comp}$file".html
		rm "${outfile}"output-"${comp}$file".html.tmp
	fi
done

