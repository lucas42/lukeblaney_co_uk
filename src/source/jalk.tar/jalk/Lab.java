import java.io.* ;
import java.net.* ;
import java.util.* ;

class Lab{
	
	private String labName;
	private BufferedReader br;
	private Computer[] comps;
	private LabThing[] things;
	private Printer[] prints;
	private String walls;
	public Lab(String labName) throws Exception{
		this.labName=labName;
		this.br = new BufferedReader(new FileReader("data/labs/"+labName+".pic"));
		
		String line;
		ArrayList compsList = new ArrayList(0);
		ArrayList thingsList = new ArrayList(0);
		ArrayList printsList = new ArrayList(0);
		String newline;
		boolean corners=false;
		boolean corIsRow=false;
		ArrayList rowList = new ArrayList(0);
		ArrayList colList = new ArrayList(0);
		rowList.add(0);
		colList.add(0);
		LabThing newlt;
		String tmp;
		while((line=br.readLine())!=null){
			if (!line.equals("")&&line.charAt(0)!='#'){
				if (corners){
					if (line.indexOf("</>")!=-1){
						corners=false;
						//System.out.println("---");
					}
					else{
						try{
							Integer val=Integer.parseInt(line);
							if (corIsRow){
								rowList.add(val);
								corIsRow=false;
						//System.out.print(val+",");
							}
							else{
								colList.add(val);
								corIsRow=true;
						//System.out.println(val);
							}
						}
						catch(NumberFormatException nfe){
							
						}
					}
				}
				else{
				
					while ((newline=br.readLine()).equals("")){} int row=Integer.parseInt(newline.trim());
					while ((newline=br.readLine()).equals("")){} int col=Integer.parseInt(newline.trim());
					if (line.indexOf("<>")!=-1){
						corners=true;
						corIsRow=true;
					}
					else{
						 if (line.indexOf("++")!=-1){
							newlt = new Printer(row, col, line.substring(2));
							printsList.add(newlt);
						}
						else if (line.indexOf("->")!=-1){
						 	tmp="<a href='map-"+line.substring(2)+"'><img src='default/door.png' alt='"+line.substring(2)+"' style='height:100%;width:100%;border:none;'></a>";
							newlt = new LabThing(row, col, "door", tmp);
							thingsList.add(newlt);
						}
						else if (line.indexOf("_-")!=-1){
						 	tmp="<a href='map-"+line.substring(4)+"'><img src='default/stairs_"+line.substring(2,4)+".png' alt='"+line.substring(2)+"' style='height:100%;width:100%;border:none;'></a>";
							newlt = new LabThing(row, col, "stair", tmp);
							thingsList.add(newlt);
						}
						else if (line.indexOf("-^")!=-1){
						 	tmp="<a href='map-"+line.substring(2)+"'><img src='default/lift.png' alt='"+line.substring(2)+"' style='height:100%;width:100%;border:none;'></a>";
							newlt = new LabThing(row, col, "lift", tmp);
							thingsList.add(newlt);
						}
						else if (line.indexOf("=>")!=-1){
							tmp="<form method='post' action='map-"+line.substring(2)+"l#"+labName+"'><input type='submit' value='"+line.substring(2)+"' style='height:100px;width:100%;'></form>";
							newlt = new LabThing(row, col, "button", tmp);
							thingsList.add(newlt);
						}
						else if (line.indexOf("__")!=-1){
							newlt = new LabThing(row, col, "txt", line.substring(2));
							thingsList.add(newlt);
						}
						else if (line.indexOf("--")!=-1){
							newlt = new LabThing(row, col, "txt-bordered", line.substring(2));
							thingsList.add(newlt);
						}
						else{
							//is a computer
							//System.out.println(line);
							newlt = new Computer(row, col, line);
							compsList.add(newlt);
							int dot1=line.indexOf(".");
							int dot2=line.indexOf(".",dot1+1);
							int dot3=line.indexOf(".",dot2+1);
							int th=Integer.parseInt(line.substring(dot2+1,dot3));
							int fr=Integer.parseInt(line.substring(dot3+1));
							Server.computers[th][fr]=(Computer)newlt;
						}
						
						//thingsList.add(newlt);
						
					}	
					
				}
				
				//System.out.println(line);
			}
		}
				
		
		comps = (Computer[])compsList.toArray( new Computer[ compsList.size() ] );
		things = (LabThing[])thingsList.toArray( new LabThing[ thingsList.size() ] );
		prints = (Printer[])printsList.toArray( new Printer[ printsList.size() ] );
		Integer[] rows = (Integer[])rowList.toArray( new Integer[ rowList.size() ] );
		Integer[] cols = (Integer[])colList.toArray( new Integer[ colList.size() ] );
		int max;
		if (rows.length <= cols.length){
			max= rows.length;
		}
		else{
			max= cols.length;
		}
		walls="";
		for (int c=1; c<max; c++){
			int top;
			int bot;
			int lft;
			int rgt;
			if (rows[c]<rows[c-1]){
				top=rows[c];
				bot=rows[c-1];
			}
			else{
				top=rows[c-1];
				bot=rows[c];
			}
			if (cols[c]<cols[c-1]){
				lft=cols[c];
				rgt=cols[c-1];
			}
			else{
				lft=cols[c-1];
				rgt=cols[c];
			}
			top*=Server.height();
			bot*=Server.height();
			lft*=Server.width();
			rgt*=Server.width();
			
			int height=bot-top;
			int width=rgt-lft;
			
			walls+="<span class='wall' style='top:"+top+"px;height:"+height+"px;left:"+lft+"px;width:"+width+"px;'></span>\n";
		}
	}
	
	public String printComps(){
		String output="";
		for (int i=0; i<comps.length; i++){
			output+=comps[i].getName()+"<br/>\n";
		}
		return output;
	}
        public void update() throws Exception{
                for (int i=0; i<comps.length; i++){
                       comps[i].update();
                }
        }
        public String getContent(String clienthost){
                String output="";
                output+=walls;
                for (int i=0; i<comps.length; i++){
					int top=Server.height()*comps[i].getRow();
					int left=Server.width()*comps[i].getCol();
           			String classes="";
					if (comps[i].getName().equals(clienthost))classes+=" localhost";
					String contents;
					if ((contents=comps[i].getContent()).equals("Not Processed")) contents="<img src=\"default/loading.gif\"/>";
                        output+="<div class='computer"+classes+"' id=\""+comps[i].getName()+"\" title=\""+comps[i].getName()+"\" style=\"position:absolute; top:"+top+"px; left:"+left+"px; min-height:"+Server.height()+"px; width:"+Server.width()+"px;\" onclick=\"extra('"+comps[i].getName()+"')\">"+contents+"</div><br/>\n";
                }
                for (int j=0; j<prints.length; j++){
					int top=Server.height()*prints[j].getRow();
					int left=Server.width()*prints[j].getCol();
           			String classes="";
					String contents;
					contents=prints[j].getShort();
                    output+="<div class='printer"+classes+"' id=\""+prints[j].getName()+"\" title=\""+prints[j].getName()+"\" style=\"position:absolute; top:"+top+"px; left:"+left+"px; min-height:"+Server.height()+"px; width:"+Server.width()+"px;\" onclick=\"printerExtra('"+prints[j].getName()+"')\">"+contents+"</div><br/>\n";
                }
                for (int k=0; k<things.length; k++){
				int top=Server.height()*things[k].getRow();
				int left=Server.width()*things[k].getCol();
				String contents="";
                        output+="<span class='"+things[k].getCssClass()+"' style=\"position:absolute; top:"+top+"px; left:"+left+"px; min-height:"+Server.height()+"px; width:"+Server.width()+"px;\">"+things[k].getContent()+"</span><br/>\n";
                }
                return output;
        }
	
	public String getName(){
		return labName;
	}
	public String toString(){
		return labName;
	}

	public Printer getPrinter(String printName){
		for (int i=0; i<prints.length; i++){
			if(prints[i].getName().trim().equals(printName.trim()))return prints[i];
		}
		return null;
	}
	public Computer getComputer(String compName){
		for (int i=0; i<comps.length; i++){
			if(comps[i].getName().trim().equals(compName.trim()))return comps[i];
		}
		return null;
	}
	public ArrayList findPerson(String person){
		ArrayList peop=new ArrayList(0);
		for (int i=0; i<comps.length; i++){
			if(comps[i].checkPerson(person))peop.add(comps[i]);
		}
		return peop;
	}
	public int getFrees(){
		int frees=0;
		for (int i=0; i<comps.length; i++){
			if(comps[i].getContent().indexOf("FREE") != -1) frees++;
		}
		//System.out.println(frees);
		return frees;
	}
}
